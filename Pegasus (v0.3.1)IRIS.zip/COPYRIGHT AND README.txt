© Copyright 2024 timetravelbeard (contact: https://www.patreon.com/timetravelbeard , https://youtube.com/@timetravelbeard3588 , https://discord.gg/S6F4r6K5yU )

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT  TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

NOTE:  In case you don't know, copyright means all rights are reserved. You cannot modify, redistribute, or make derivative works of this. Do not steal any of this code or use "code snippets". 



If you want to learn to make shaders I started a video series here:
https://youtu.be/KuAiWzlu2oo?si=2oaXlYC47le8T2x4


If you enjoy this shader, or have suggestions, please come tell me on discord, and check out my other projects! https://discord.gg/S6F4r6K5yU  
you can also leave a tip or join on my patreon here:  https://www.patreon.com/timetravelbeard


If the texture upscaling looks broken on certain things, you can whitelist mobs for filter fixes, or blacklist them from upscaling, in the 'entity.properties' file. If you tell me the names, I'll include them in the next update.
